package com.cts.buyer.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cts.buyer.entity.BuyerInfo;
import com.cts.buyer.entity.CartItems;
import com.cts.buyer.model.BuyerCartResponse;
import com.cts.buyer.services.CartService;


@RestController
@CrossOrigin("*")
@RequestMapping("/cart")
public class CartController {
	
	@Autowired
	private CartService cartService;
	
	@RequestMapping(value = "/addcartitem/{buyerId}", method = RequestMethod.POST, produces = "application/json")
	public CartItems addCartItems(@PathVariable(value = "buyerId") Integer buyerId,@RequestBody CartItems cartItem) {
		System.out.println("controller"+ cartItem);
		Optional<CartItems> savedItem = cartService.addItemToCart(cartItem, buyerId);
		return savedItem.get();
	}
	
	
	@RequestMapping(value = "/getallitems/{buyerId}", method = RequestMethod.GET,produces = "application/json") 
	public List<BuyerCartResponse> getAllCartItem(@PathVariable("buyerId") Integer buyerId) { 
		List<BuyerCartResponse>Items = cartService.getallCartItems(buyerId); 
		return Items; 
	}

	@RequestMapping(value = "/deletebyid/{cartItemId}", method = RequestMethod.DELETE)
	public void deleteByCartItemId(@PathVariable(value = "cartItemId") Integer cartItemId) {
		String status = cartService.deleteCartItem(cartItemId);
	}
	
	@RequestMapping(value = "/update", method = RequestMethod.PUT, produces = "application/json")
	public BuyerCartResponse updateCartItems(@RequestBody BuyerCartResponse cartItem) {
		return cartService.updateCartItem(cartItem);
	}
	
	@RequestMapping(value = "/{buyerId}/deleteall", method = RequestMethod.DELETE)
	public String deleteAllItems(@PathVariable(value = "buyerId") Integer buyerId) {
		return cartService.emptyCartItems(buyerId);
	}
	
	@RequestMapping(value = "/{buyerId}/checkout", method = RequestMethod.GET)
	public String checkout(@PathVariable(value = "buyerId") Integer buyerId) {
		return cartService.checkout(buyerId);
	}
}
