package com.cts.buyer.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cts.buyer.entity.BuyerInfo;
import com.cts.buyer.entity.CartItems;
import com.cts.buyer.services.CartService;


@RestController
@RequestMapping("/cart")
public class CartController {
	
	@Autowired
	private CartService cartService;
	
	@RequestMapping(value = "/{buyerId}/addcartitem", method = RequestMethod.POST, produces = "application/json")
	public CartItems addCartItems(@PathVariable(value = "buyerId") Integer buyerId,@RequestBody CartItems cartItem) {
		Optional<CartItems> savedItem = cartService.addItemToCart(cartItem, buyerId);
		return savedItem.get();
	}
	
	
	@RequestMapping(value = "/{buyerId}/getallitems", method = RequestMethod.GET,produces = "application/json") 
	public List<CartItems> getAllCartItem(@PathVariable("buyerId") Integer buyerId) { 
		List<CartItems>Items = cartService.getallCartItems(buyerId); 
		return Items; 
	}

	@RequestMapping(value = "/{cartItemId}/deletebyid", method = RequestMethod.DELETE)
	public String deleteByCartItemId(@PathVariable(value = "cartItemId") Integer cartItemId) {
		String status = cartService.deleteCartItem(cartItemId);
		return status;
	}
	
	@RequestMapping(value = "/{cartItemId}/update", method = RequestMethod.PUT, produces = "application/json")
	public CartItems updateCartItems(@PathVariable(value = "cartItemId") Integer cartItemId,@RequestBody CartItems cartItem) {
		return cartService.updateCartItem(cartItem, cartItemId);
	}
	
	@RequestMapping(value = "/{buyerId}/deleteall", method = RequestMethod.DELETE)
	public String deleteAllItems(@PathVariable(value = "buyerId") Integer buyerId) {
		return cartService.emptyCartItems(buyerId);
	}
	
	@RequestMapping(value = "/{buyerId}/checkout", method = RequestMethod.POST)
	public String checkout(@PathVariable(value = "buyerId") Integer buyerId) {
		return cartService.checkout(buyerId);
	}
}
