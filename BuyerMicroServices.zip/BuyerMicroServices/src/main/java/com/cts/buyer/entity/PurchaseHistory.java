package com.cts.buyer.entity;

import java.time.LocalDate;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
public class PurchaseHistory {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer purchaseHistoryId;
	@ManyToOne
	@JoinColumn(name = "buyerId")
	private BuyerInfo buyer;
	@ManyToOne
	@JoinColumn(name = "transactionId")
	private TransactionHistory transaction;
	private Integer itemId;
	private Integer numberOfItems;
	@JsonFormat(pattern = "dd/MM/yyyy")
	private LocalDate dateTime;
	private String remarks;
	
	
	public PurchaseHistory() {
		super();
	}
	
	
	public PurchaseHistory(Integer purchaseHistoryId, BuyerInfo buyer, TransactionHistory transaction, Integer itemId,
			Integer numberOfItems, LocalDate dateTime, String remarks) {
		super();
		this.purchaseHistoryId = purchaseHistoryId;
		this.buyer = buyer;
		this.transaction = transaction;
		this.itemId = itemId;
		this.numberOfItems = numberOfItems;
		this.dateTime = dateTime;
		this.remarks = remarks;
	}


	public Integer getPurchaseHistoryId() {
		return purchaseHistoryId;
	}


	public void setPurchaseHistoryId(Integer purchaseHistoryId) {
		this.purchaseHistoryId = purchaseHistoryId;
	}

	public BuyerInfo getBuyer() {
		return buyer;
	}


	public void setBuyer(BuyerInfo buyer) {
		this.buyer = buyer;
	}


	public TransactionHistory getTransaction() {
		return transaction;
	}


	public void setTransaction(TransactionHistory transaction) {
		this.transaction = transaction;
	}


	public Integer getItemId() {
		return itemId;
	}


	public void setItemId(Integer itemId) {
		this.itemId = itemId;
	}


	public Integer getNumberOfItems() {
		return numberOfItems;
	}


	public void setNumberOfItems(Integer numberOfItems) {
		this.numberOfItems = numberOfItems;
	}


	public LocalDate getDateTime() {
		return dateTime;
	}


	public void setDateTime(LocalDate dateTime) {
		this.dateTime = dateTime;
	}


	public String getRemarks() {
		return remarks;
	}


	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
}
