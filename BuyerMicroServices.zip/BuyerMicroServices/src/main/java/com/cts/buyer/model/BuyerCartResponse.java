package com.cts.buyer.model;

public class BuyerCartResponse {

	private Integer cartItemId;
	private Integer itemId;
	private Integer quantity;
	private Double price;
	
	public BuyerCartResponse(Integer cartItemId, Integer itemId, Integer quantity, Double price) {
		super();
		this.cartItemId = cartItemId;
		this.itemId = itemId;
		this.quantity = quantity;
		this.price = price;
	}


	
	public Double getPrice() {
		return price;
	}



	public void setPrice(Double price) {
		this.price = price;
	}



	public Integer getCartItemId() {
		return cartItemId;
	}


	public void setCartItemId(Integer cartItemId) {
		this.cartItemId = cartItemId;
	}


	public Integer getItemId() {
		return itemId;
	}


	public void setItemId(Integer itemId) {
		this.itemId = itemId;
	}


	public Integer getQuantity() {
		return quantity;
	}


	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}


	public BuyerCartResponse() {
		// TODO Auto-generated constructor stub
	}

}
