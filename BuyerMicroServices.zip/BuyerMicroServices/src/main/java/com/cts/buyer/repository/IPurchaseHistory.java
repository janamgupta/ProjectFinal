package com.cts.buyer.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cts.buyer.entity.CartItems;
import com.cts.buyer.entity.PurchaseHistory;

@Repository
public interface IPurchaseHistory extends JpaRepository<PurchaseHistory, Integer>{

	@Query(value = "SELECT * FROM purchase_history WHERE purchase_history.buyer_id = :buyerId", nativeQuery = true)
	public List<PurchaseHistory> getPurchaseHistory(@Param("buyerId")Integer buyerId); 
}
