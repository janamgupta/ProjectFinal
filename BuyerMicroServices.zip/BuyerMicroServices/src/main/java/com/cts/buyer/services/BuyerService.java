package com.cts.buyer.services;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.cts.buyer.entity.BuyerInfo;
import com.cts.buyer.entity.PurchaseHistory;
import com.cts.buyer.repository.IAddressRepository;
import com.cts.buyer.repository.IBuyerRepository;
import com.cts.buyer.repository.IPurchaseHistory;
@Service
public class BuyerService implements UserDetailsService{
	
	@Autowired
	private IBuyerRepository buyerRepository;
	
	@Autowired
	private IAddressRepository addressRepository;
	
	@Autowired
	private IPurchaseHistory purchaseRepository;
	
	@Autowired
	private BCryptPasswordEncoder bcryptEncoder;
	
	public BuyerInfo addBuyer(BuyerInfo buyer) {
		addressRepository.save(buyer.getBuyerAddress());
		buyer.setPassword(bcryptEncoder.encode(buyer.getPassword()));
		return buyerRepository.save(buyer);
	}
	
	public List<PurchaseHistory> getPurchaseHistory(Integer buyerId){
		return purchaseRepository.getPurchaseHistory(buyerId);
	}

	public BuyerInfo findBuyer(String username) {
		return buyerRepository.getByBuyerName(username);
	}

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		BuyerInfo buyer = buyerRepository.getByBuyerName(username);
		if(buyer == null){
			throw new UsernameNotFoundException("Invalid username or password.");
		}
		return new org.springframework.security.core.userdetails.User(buyer.getBuyerName(), buyer.getPassword(), getAuthority());
	}

	private List<SimpleGrantedAuthority> getAuthority() {
		return Arrays.asList(new SimpleGrantedAuthority("ROLE_BUYER"));
	}
}
