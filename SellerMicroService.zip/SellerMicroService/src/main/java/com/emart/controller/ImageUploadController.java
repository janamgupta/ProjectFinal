package com.emart.controller;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.Optional;
import java.util.zip.DataFormatException;
import java.util.zip.Deflater;
import java.util.zip.Inflater;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.ResponseEntity.BodyBuilder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.emart.entity.Category;
import com.emart.entity.Items;
import com.emart.entity.Seller;
import com.emart.entity.SubCategory;
import com.emart.model.SearchItemResponse;
import com.emart.repository.IItem;
import com.emart.services.ItemService;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping(path = "image")
public class ImageUploadController {

	@Autowired
	 ItemService itemService;
	
	@Autowired
	IItem itemRepository;

	@PostMapping("/upload")
	public BodyBuilder uplaodImage(@RequestParam("imageFile") MultipartFile file, @RequestParam("itemname") String itemName,
			@RequestParam("seller") String seller, @RequestParam("category") String category , @RequestParam("subcategory") String subCategory,
			@RequestParam("price") String price, @RequestParam("stock") String stock, @RequestParam("desc") String description, @RequestParam("remark") String remark) 
	throws IOException {
		System.out.println("Original Image Byte Size - " + file.getBytes().length);
		Seller sellerId = new Seller();
		Category categoryId = new Category();
		SubCategory subCategoryId = new SubCategory();
		
		sellerId.setSellerId(Integer.parseInt(seller));
		categoryId.setCategoryId(Integer.parseInt(category));
		subCategoryId.setSubCategoryId(Integer.parseInt(subCategory));
		
		Items item = new  Items(itemName, sellerId, categoryId, subCategoryId, Double.parseDouble(price), Integer.parseInt(stock),
				description, remark, compressZLib(file.getBytes()));
		itemService.addItems(item);
		return ResponseEntity.status(HttpStatus.OK);
	}

//	@GetMapping(path = { "/get/{itemId}" })
//	public Items getImage(@PathVariable("itemId") Integer itemId) throws IOException {
//
//		final Optional<Items> retrievedItem = itemRepository.findById(itemId);
//		Items item = new Items(retrievedItem.get().getItemName(), retrievedItem.get().getSeller(), retrievedItem.get().getCategoryId(), retrievedItem.get().getSubCategoryId(), retrievedItem.get().getPrice(), 
//				retrievedItem.get().getStock(), retrievedItem.get().getDescription(), retrievedItem.get().getRemarks(),  decompressZLib(retrievedItem.get().getImage()));
//		return item;
//	}

	@GetMapping(value = "/getAll")
	public List<SearchItemResponse> getAll(){
		return itemService.getAll();
	}
	// compress the image bytes before storing it in the database
	public static byte[] compressZLib(byte[] data) {
		Deflater deflater = new Deflater();
		deflater.setInput(data);
		deflater.finish();

		ByteArrayOutputStream outputStream = new ByteArrayOutputStream(data.length);
		byte[] buffer = new byte[1024];
		while (!deflater.finished()) {
			int count = deflater.deflate(buffer);
			outputStream.write(buffer, 0, count);
		}
		try {
			outputStream.close();
		} catch (IOException e) {
		}
		System.out.println("Compressed Image Byte Size - " + outputStream.toByteArray().length);

		return outputStream.toByteArray();
	}

	// uncompress the image bytes before returning it to the angular application
//	public static byte[] decompressZLib(byte[] data) {
//		Inflater inflater = new Inflater();
//		inflater.setInput(data);
//		ByteArrayOutputStream outputStream = new ByteArrayOutputStream(data.length);
//		byte[] buffer = new byte[1024];
//		try {
//			while (!inflater.finished()) {
//				int count = inflater.inflate(buffer);
//				outputStream.write(buffer, 0, count);
//			}
//			outputStream.close();
//		} catch (IOException ioe) {
//		} catch (DataFormatException e) {
//		}
//		return outputStream.toByteArray();
//	}
}