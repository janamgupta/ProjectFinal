package com.emart.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.emart.entity.Items;
import com.emart.entity.Seller;
import com.emart.model.SearchItemResponse;
import com.emart.services.ItemService;
import com.emart.services.SellerService;

@RestController
@CrossOrigin("*")
@RequestMapping("/seller")
public class SellerController {
	
	@Autowired
	private SellerService sellerService;
	
	@Autowired
	private ItemService itemService;
	
	@PostMapping(value ="/signup", produces = "application/json")
	public Seller addSeller(@RequestBody Seller seller) {
		return sellerService.addSeller(seller); 
	}
	
	@PostMapping(value = "/{sellerId}/additems", produces = "application/json")
	public Items addItems(@RequestBody Items item, @PathVariable("sellerId") Integer sellerId) {
		return itemService.addItems(item, sellerId);  
	}
	
	@PutMapping(value = "/{itemId}/updateitems", produces = "application/json")
	public Items updateItem(@RequestBody Items item, @PathVariable("itemId") Integer itemId) {
		return itemService.updateItem(item, itemId);
	}
	
	@DeleteMapping(value = "/{sellerId}/deleteitem/{itemId}")
	public void deleteItem(@PathVariable("sellerId") Integer sellerId, @PathVariable("itemId") Integer itemId) {
		itemService.deleteitem(sellerId, itemId);
	}
	
	@GetMapping(value = "/{sellerId}/getallitems", produces = "application/json")
	public List<Items> getAllItems(@PathVariable("sellerId") Integer sellerId){
		return itemService.getAllitems(sellerId);
	}
	
	@GetMapping(value = "/search/{searchString}", produces = "application/json")
	public List<SearchItemResponse> searchByName(@PathVariable("searchString") String searchString){
		return itemService.searchByName(searchString.toLowerCase());
	}
}
