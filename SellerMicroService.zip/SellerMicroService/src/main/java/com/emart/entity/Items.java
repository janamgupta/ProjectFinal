package com.emart.entity;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "item_seller")
public class Items implements Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer itemId;
	private String itemName;
	@ManyToOne
	@JoinColumn(name = "sellerId")
	private Seller seller;
	@ManyToOne
	@JoinColumn(name = "categoryId")
	private Category category;
	@ManyToOne
	@JoinColumn(name = "subCategoryId")
	private SubCategory subCategory;
	private Double price;
	private byte[] image;
	private Integer stock;
	private String description;
	private String remarks;

	public Items(String itemName, Seller seller,Category category, SubCategory subCategory, Double price, Integer stock,
			String description, String remarks, byte[] image) {
		super();
		this.itemName = itemName;
		this.seller = seller;
		this.category = category;
		this.subCategory = subCategory;
		this.price = price;
		this.stock = stock;
		this.description = description;
		this.remarks = remarks;
		this.image = image;
	}


	public Items() {
		// TODO Auto-generated constructor stub
	}


	public byte[] getImage() {
		return image;
	}


	public void setImage(byte[] image) {
		this.image = image;
	}


	public Integer getItemId() {
		return itemId;
	}


	public void setItemId(Integer itemId) {
		this.itemId = itemId;
	}


	public String getItemName() {
		return itemName;
	}


	public void setItemName(String itemName) {
		this.itemName = itemName;
	}


	public Seller getSeller() {
		return seller;
	}


	public void setSeller(Seller seller) {
		this.seller = seller;
	}


	public Category getCategoryId() {
		return category;
	}


	public void setCategoryId(Category category) {
		this.category = category;
	}


	public SubCategory getSubCategoryId() {
		return subCategory;
	}


	public void setSubCategoryId(SubCategory subCategory) {
		this.subCategory = subCategory;
	}


	public Double getPrice() {
		return price;
	}


	public void setPrice(Double price) {
		this.price = price;
	}


	public Integer getStock() {
		return stock;
	}


	public void setStock(Integer stock) {
		this.stock = stock;
	}


	public String getDescription() {
		return description;
	}


	public void setDescription(String description) {
		this.description = description;
	}


	public String getRemarks() {
		return remarks;
	}


	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
}
