package com.emart.entity;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class SubCategory implements Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer subCategoryId;
	private String subCategoryName;
	@ManyToOne
	@JoinColumn(name = "categoryId")
	private Category category;
	private String briefDetail;
	private Integer gst;
	
	public SubCategory() {
		// TODO Auto-generated constructor stub
	}
	
	public SubCategory(String subCategoryName, Category category, String briefDetail, Integer gst) {
		super();
		this.subCategoryName = subCategoryName;
		this.category = category;
		this.briefDetail = briefDetail;
		this.gst = gst;
	}



	public String getSubCategoryName() {
		return subCategoryName;
	}

	public void setSubCategoryName(String subCategoryName) {
		this.subCategoryName = subCategoryName;
	}

	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

	public String getBriefDetail() {
		return briefDetail;
	}

	public void setBriefDetail(String briefDetail) {
		this.briefDetail = briefDetail;
	}

	public Integer getGst() {
		return gst;
	}

	public void setGst(Integer gst) {
		this.gst = gst;
	}

	public Integer getSubCategoryId() {
		return subCategoryId;
	}

	public void setSubCategoryId(Integer subCategoryId) {
		this.subCategoryId = subCategoryId;
	}
	
	
}
