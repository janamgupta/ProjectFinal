package com.emart.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.emart.entity.Items;
import com.emart.entity.Seller;
import com.emart.repository.IItem;
import com.emart.repository.ISeller;

@Service
public class ItemService {

	@Autowired
	private IItem itemRepository;
	
	@Autowired
	private ISeller sellerRepository;

	public Items addItems(Items item, Integer sellerId) {
		Optional<Seller> seller = sellerRepository.findById(sellerId);
		item.setSeller(seller.get());
		return itemRepository.save(item);
	}
	
	public List<Items> getAllitems(Integer sellerId){
		return itemRepository.findBySellerId(sellerId);
	}
	
	public void deleteitem(Integer sellerId, Integer itemId) {
		itemRepository.deleteItemById(sellerId, itemId);
	}
	
	public Items updateItem(Items item, Integer ItemId) {
		Optional<Items> oldItem = itemRepository.findById(ItemId);
		if(oldItem.isPresent()) {
			Items updatedItem = oldItem.get();
			updatedItem.setCategoryId(item.getCategoryId());
			updatedItem.setDescription(item.getDescription());
			updatedItem.setItemName(item.getItemName());
			updatedItem.setRemarks(item.getRemarks());
			updatedItem.setStock(item.getStock());
			updatedItem.setPrice(item.getPrice());
			updatedItem.setSubCategoryId(item.getSubCategoryId());
			return itemRepository.save(updatedItem);
		}
		return null;
	}
}
