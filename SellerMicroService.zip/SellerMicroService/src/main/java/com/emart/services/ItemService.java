package com.emart.services;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.zip.DataFormatException;
import java.util.zip.Inflater;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.emart.entity.Items;
import com.emart.entity.Seller;
import com.emart.model.CartResponse;
import com.emart.model.SearchItemResponse;
import com.emart.repository.IItem;
import com.emart.repository.ISeller;

@Service
public class ItemService {

	@Autowired
	private IItem itemRepository;
	
	@Autowired
	private ISeller sellerRepository;

	public Items addItems(Items item) {
		Optional<Seller> seller = sellerRepository.findById(item.getSeller().getSellerId());
		item.setSeller(seller.get());
		return itemRepository.save(item);
	}
	
	public List<Items> getAllitems(Integer sellerId){
		return itemRepository.findBySellerId(sellerId);
	}
	
	public void deleteitem(Integer sellerId, Integer itemId) {
		itemRepository.deleteItemById(sellerId, itemId);
	}
	
	public Items updateItem(Items item, Integer ItemId) {
		Optional<Items> oldItem = itemRepository.findById(ItemId);
		if(oldItem.isPresent()) {
			Items updatedItem = oldItem.get();
			updatedItem.setCategoryId(item.getCategoryId());
			updatedItem.setDescription(item.getDescription());
			updatedItem.setItemName(item.getItemName());
			updatedItem.setRemarks(item.getRemarks());
			updatedItem.setStock(item.getStock());
			updatedItem.setPrice(item.getPrice());
			updatedItem.setSubCategoryId(item.getSubCategoryId());
			return itemRepository.save(updatedItem);
		}
		return null;
	}
	
	public List<SearchItemResponse> searchByName(String searchString){
		List<Items> allItems = itemRepository.searchByName(searchString);
		List<SearchItemResponse> responseItemList = new ArrayList<SearchItemResponse>();
		
		for(Items item : allItems) {
			SearchItemResponse responseItem = new SearchItemResponse();
			responseItem.setCategoryId(item.getCategoryId().getCategoryId());
			responseItem.setCategoryName(item.getCategoryId().getCategoryName());
			responseItem.setItemId(item.getItemId());
			responseItem.setItemName(item.getItemName());
			responseItem.setSellerId(item.getSeller().getSellerId());
			responseItem.setStock(item.getStock());
			responseItem.setPrice(item.getPrice());
			responseItem.setSubCategoryId(item.getSubCategoryId().getSubCategoryId());
			responseItem.setSubCategoryName(item.getSubCategoryId().getSubCategoryName());
			responseItemList.add(responseItem);
		}
		return responseItemList;
	}
	
	public List<SearchItemResponse> getAll(){
		
		List<SearchItemResponse> viewItemList = new ArrayList<SearchItemResponse>();
		List<Items> itemList =  itemRepository.findAll();
		
		for(Items item : itemList) {
			SearchItemResponse viewItem = new SearchItemResponse();
			viewItem.setCategoryId(item.getCategoryId().getCategoryId());
			viewItem.setCategoryName(item.getCategoryId().getCategoryName());
			viewItem.setItemId(item.getItemId());
			viewItem.setItemName(item.getItemName());
			viewItem.setPrice(item.getPrice());
			viewItem.setSellerId(item.getSeller().getSellerId());
			viewItem.setStock(item.getStock());
			viewItem.setSubCategoryId(item.getSubCategoryId().getSubCategoryId());
			viewItem.setSubCategoryName(item.getSubCategoryId().getSubCategoryName());
			viewItem.setImage(decompressZLib(item.getImage()));
			viewItemList.add(viewItem);
		}
		return viewItemList;
	}
	
	public void updateStock(List<CartResponse> cartResponse) {
		for(CartResponse cart : cartResponse) {
		Optional<Items> item = itemRepository.findById(cart.getItemId());
		Items updatedItem = item.get();
		Integer initialQuantity = updatedItem.getStock();
		updatedItem.setStock(initialQuantity - cart.getItemQuantity());
		itemRepository.save(updatedItem);
		}
	}
	
	public static byte[] decompressZLib(byte[] data) {
		Inflater inflater = new Inflater();
		inflater.setInput(data);
		ByteArrayOutputStream outputStream = new ByteArrayOutputStream(data.length);
		byte[] buffer = new byte[1024];
		try {
			while (!inflater.finished()) {
				int count = inflater.inflate(buffer);
				outputStream.write(buffer, 0, count);
			}
			outputStream.close();
		} catch (IOException ioe) {
		} catch (DataFormatException e) {
		}
		return outputStream.toByteArray();
	}
}
