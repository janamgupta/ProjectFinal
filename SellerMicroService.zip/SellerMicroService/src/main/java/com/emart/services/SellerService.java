package com.emart.services;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import com.emart.entity.Seller;
import com.emart.repository.IAddress;
import com.emart.repository.ISeller;

@Service
public class SellerService implements UserDetailsService{
	
	@Autowired
	private ISeller sellerRepository;
	
	@Autowired
	private IAddress addressRepository;
	
	@Autowired
	private BCryptPasswordEncoder bCryptEncoder;
	public Seller addSeller(Seller seller) {
		addressRepository.save(seller.getPostalAddress());
		seller.setPassword(bCryptEncoder.encode(seller.getPassword()));
		return sellerRepository.save(seller);
	}

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		Seller seller = sellerRepository.getByUsername(username);
		if(seller == null){
			throw new UsernameNotFoundException("Invalid username or password.");
		}
		return new org.springframework.security.core.userdetails.User(seller.getUsername(), seller.getPassword(), getAuthority());
	}

	private List<SimpleGrantedAuthority> getAuthority() {
		return Arrays.asList(new SimpleGrantedAuthority("ROLE_SELLER"));
	}

	public Seller getSeller(String username) {
		return sellerRepository.getByUsername(username);
	}
}
