import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  title = 'Emart';
  loginButtonDisable : boolean =  false;
  searchStr: string ;
  ngOnInit(): void {
    if(window.localStorage.getItem('token')){
      this.loginButtonDisable = true;
    }
  }
}
