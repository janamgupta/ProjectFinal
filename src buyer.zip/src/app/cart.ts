export class Cart{
    
    itemId:number;
    quantity:number = 1;
    
}

export class ViewCart{
    
    cartId:number;
    itemId:number;
    quantity:number;

}