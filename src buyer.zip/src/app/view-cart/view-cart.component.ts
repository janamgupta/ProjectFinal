import { Component, OnInit } from '@angular/core';
import { ViewCart } from '../cart';
import { BuyerService } from '../buyer.service';

@Component({
  selector: 'app-view-cart',
  templateUrl: './view-cart.component.html',
  styleUrls: ['./view-cart.component.css']
})
export class ViewCartComponent implements OnInit {

  viewCart : ViewCart = new ViewCart();
  view : ViewCart[];

  constructor(private buyerService: BuyerService) { }

  ngOnInit(): void {
    this.buyerService.viewCart().subscribe(itemview => this.view = itemview);
  }

  increment(cartView : ViewCart){
    cartView.quantity += 1;
    this.buyerService.updateCart(cartView).subscribe(newView => this.viewCart = newView);
  }

  decrement(cartView : ViewCart){
    cartView.quantity -= 1;
    this.buyerService.updateCart(cartView).subscribe(newView => this.viewCart = newView);
  }

  checkoutCart(){
    this.buyerService.checkoutCart();
  }
}
