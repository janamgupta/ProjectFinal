import { Injectable } from '@angular/core';
import { ApiResponse } from './api.response';
import { Observable } from 'rxjs';
import {HttpClient } from '@angular/common/http';
import { SellerInfo } from './sellerDetails';

@Injectable({
  providedIn: 'root'
})
export class SellerServiceService {
  login(loginPayload) : Observable<ApiResponse> {
    return this.http.post<ApiResponse>('http://localhost:8080/' + 'token/generate-token', loginPayload);
  }

  signup(seller:SellerInfo) : Observable<ApiResponse> {
    return this.http.post<ApiResponse>('http://localhost:8080/' + 'seller/signup', seller);
  }
  constructor(private http : HttpClient) { }
}
