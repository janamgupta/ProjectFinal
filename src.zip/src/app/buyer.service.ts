import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { ApiResponse } from './api.response';

@Injectable({
  providedIn: 'root'
})
export class BuyerService {
  
  login(loginPayload) : Observable<ApiResponse> {
    return this.http.post<ApiResponse>('http://localhost:8081/' + 'token/generate-token', loginPayload);
  }

  constructor(private http: HttpClient) { }

  private baseUrl = 'http://localhost:8081/buyer';

  createBuyer(buyer: Object): Observable<Object> {
    console.log(buyer);
    return this.http.post(`${this.baseUrl}` + `/signup`, buyer);
  }

}
