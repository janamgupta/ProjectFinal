import { Component, OnInit } from '@angular/core';
import { Item } from '../item';
import { BuyerService } from '../buyer.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  items: Item[];

  constructor(private buyerService : BuyerService) { }

  ngOnInit(): void {

    this.buyerService.getAllItems().subscribe(items => this.items = items);
  }

 // searchStr: string;
  

}
