import { Component, OnInit, Input } from '@angular/core';
import { Item } from '../item';
import { Cart } from '../cart';
import { BuyerService } from '../buyer.service';

@Component({
  selector: 'app-product-details',
  templateUrl: './product-details.component.html',
  styleUrls: ['./product-details.component.css']
})
export class ProductDetailsComponent implements OnInit {

  @Input() item: Item;
  
  constructor(private buyerService : BuyerService) { }

  ngOnInit(): void {
  }

  onSave(itemId : number, price : number){
    let cart:Cart = new Cart();
    
    cart.itemId = itemId;
    cart.quantity = 1;
    cart.price = price;
    this.buyerService.addToCart(cart).subscribe(()=>alert("added to cart"),
    error => console.log('ERRORrrrrrrrrrrrrrrrrrrrrr: ' + error));
  }
}
