import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormGroup, FormsModule, FormControl } from '@angular/forms';
import { userInfo, Address } from '../userdetails';
import { BuyerService } from '../buyer.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  constructor(private formBuilder : FormBuilder,private buyerService : BuyerService) { }
  userForm : any;
  buyerResponse : any;
  ngOnInit(): void {
    this.userForm = this.formBuilder.group({
      Name: ['',[Validators.required]],
      primaryMobileNumber: ['',[Validators.required]],
      email: ['',[Validators.required]],
      password: ['',[Validators.required]],
      secondaryMobileNumber: ['',[Validators.required]],
      houseNo: ['',[Validators.required]],
      streetName: ['',[Validators.required]],
      city: ['',[Validators.required]],
      state: ['',[Validators.required]],
      locality: ['',[Validators.required]],
      pincode: ['',[Validators.required]]
    });
  }

  buyerInfo : userInfo = new userInfo();
  onSubmit(){
    if (this.userForm.invalid) {
      return;
    }
    this.buyerInfo.buyerName = this.userForm.controls.Name.value;  
    this.buyerInfo.password = this.userForm.controls.password.value;  
    this.buyerInfo.buyerMobileNumberPrimary = this.userForm.controls.primaryMobileNumber.value;  
    this.buyerInfo.buyerEmail = this.userForm.controls.email.value;  
    this.buyerInfo.buyerMobileNumberSecondary = this.userForm.controls.secondaryMobileNumber.value;  
    this.buyerInfo.buyerAddress.houseNumber = this.userForm.controls.houseNo.value;  
    this.buyerInfo.buyerAddress.streetName = this.userForm.controls.streetName.value;  
    this.buyerInfo.buyerAddress.city = this.userForm.controls.city.value;  
    this.buyerInfo.buyerAddress.state = this.userForm.controls.state.value;  
    this.buyerInfo.buyerAddress.locality = this.userForm.controls.locality.value;  
    this.buyerInfo.buyerAddress.pinCode = this.userForm.controls.pincode.value;  
    this.buyerService.createBuyer(this.buyerInfo).subscribe(()=>alert("signed up successfully"));
  }
}
