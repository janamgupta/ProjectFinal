import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { userInfo, Address } from '../userdetails';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  constructor(private formBuilder : FormBuilder) { }
  userForm: any;
  ngOnInit(): void {
    this.userForm = this.formBuilder.group({
      Name: ['', [Validators.required, Validators.pattern('^[a-zA-Z]+$')]],
      primaryMobileNumber: ['', [Validators.required, Validators.maxLength(10), Validators.minLength(10), Validators.pattern('^[0-9]+$')]],
      email: ['',[Validators.required, Validators.email]],
      password: ['',[Validators.required]],
      secondaryMobileNumber: ['', [Validators.required, Validators.maxLength(10), Validators.minLength(10), Validators.pattern('^[0-9]+$')]],
      houseNo: ['',[Validators.required]],
      streetName: ['',[Validators.required]],
      city: ['',[Validators.required]],
      state: ['',[Validators.required]],
      locality: ['',[Validators.required]],
      pincode: ['', [Validators.required, Validators.maxLength(6), Validators.minLength(10), Validators.pattern('^[0-9]+$')]]
    });
  }

  buyerInfo : userInfo;
  buyerAddress : Address;
  onSubmit(){
    if(this.userForm.valid){
      this.buyerInfo.buyerName = this.userForm.Name;
      this.buyerInfo.password = this.userForm.password;
      this.buyerInfo.buyerEmail = this.userForm.email;
      this.buyerInfo.buyerMobileNumberPrimary = this.userForm.primaryMobileNumber;
      this.buyerInfo.buyerMobileNumberSecondary = this.userForm.secondaryMobileNumber;
      this.buyerInfo.buyerAddress.houseNumber = this.userForm.houseNo;
      this.buyerInfo.buyerAddress.streetName = this.userForm.streetName;
      this.buyerInfo.buyerAddress.city = this.userForm.houseNo.city;
      this.buyerInfo.buyerAddress.locality = this.userForm.houseNo.locality;
      this.buyerInfo.buyerAddress.pinCode = this.userForm.houseNo.pincode;
    } else {
      alert('User form is not valid!!')
    }
  }
}
