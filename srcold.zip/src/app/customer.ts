export class Customer {
    id: number;
    name: string;
    age: number;
    active: boolean;
}

export class SearchItem {
    //searchString : string;
    constructor( private searchString:string ){
        
    }
}

export class Item {

    itemId : number;
    sellerId : number;
    categoryId:number;
    subCategoryId:number;
    price:number;
    itemName:string;
    categoryName:string;
    stock:number;
    subCategoryName:string;
} 

export class Cart{
    
    itemId:number;
    quantity:number = 1;
    
}

export class ViewCart{
    
    cartId:number;
    itemId:number;
    quantity:number;

}

   