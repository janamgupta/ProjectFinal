import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GetitemlistComponent } from './getitemlist.component';

describe('GetitemlistComponent', () => {
  let component: GetitemlistComponent;
  let fixture: ComponentFixture<GetitemlistComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GetitemlistComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GetitemlistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
