import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-getitemlist',
  templateUrl: './getitemlist.component.html',
  styleUrls: ['./getitemlist.component.css']
})
export class GetitemlistComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
