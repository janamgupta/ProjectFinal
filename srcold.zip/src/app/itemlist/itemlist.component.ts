import { Component, OnInit, Input } from '@angular/core';
import { CustomerService } from '../customer.service';
import { Item } from '../customer';

@Component({
  selector: 'app-itemlist',
  templateUrl: './itemlist.component.html',
  styleUrls: ['./itemlist.component.css']
})
export class ItemlistComponent implements OnInit {

  @Input() item : Item;
  
  constructor(private productService : CustomerService) { }

  ngOnInit(): void {
  }

}
