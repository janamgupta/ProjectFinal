import { Component, OnInit, Input } from '@angular/core';
import { Item, Cart } from '../customer';
import { CustomerService } from '../customer.service';


@Component({
  selector: 'app-product-details',
  templateUrl: './product-details.component.html',
  styleUrls: ['./product-details.component.css']
})
export class ProductDetailsComponent implements OnInit {

  @Input() item: Item;
  abc:any;
  constructor(private productService : CustomerService) { }

  ngOnInit() {
  }

  onSave(itemId : number){
    //console.log("aaaaaaaaaaaaaaaa");
    let cart:Cart = new Cart();
    
    cart.itemId = itemId;
    cart.itemQuantity = 1;
    this.productService.addToCart(cart).subscribe(abc=>{this.abc=abc;},
    error => console.log('ERRORrrrrrrrrrrrrrrrrrrrrr: ' + error));
    //this.productService.getCustomersByString1("s");
    
  }
}
