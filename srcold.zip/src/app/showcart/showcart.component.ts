import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../customer.service';
import { ViewCart } from '../customer';

@Component({
  selector: 'app-showcart',
  templateUrl: './showcart.component.html',
  styleUrls: ['./showcart.component.css']
})
export class ShowcartComponent implements OnInit {


  constructor(private cartservice : CustomerService) { }

  viewCart : ViewCart = new ViewCart();
  view : ViewCart[];

  ngOnInit(): void {

    this.cartservice.viewCart().subscribe(itemview => this.view = itemview);
  }

  increment(cartView : ViewCart){
    cartView.quantity += 1;
    this.cartservice.updateCart(cartView).subscribe(newView => this.viewCart = newView);
  }

  decrement(cartView : ViewCart){
    cartView.quantity -= 1;
    this.cartservice.updateCart(cartView).subscribe(newView => this.viewCart = newView);
  }

  checkoutCart(){
    this.cartservice.checkoutCart();
  }

}
