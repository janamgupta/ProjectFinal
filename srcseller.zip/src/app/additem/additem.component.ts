import { Component, OnInit } from '@angular/core';
import { SellerServiceService } from '../seller-service.service';

@Component({
  selector: 'app-additem',
  templateUrl: './additem.component.html',
  styleUrls: ['./additem.component.css']
})
export class AdditemComponent implements OnInit {

    itemName : any;
	  price : any;
    stock : any;
	  description : any;
    remarks : any;
    categoryName : any;
    categoryId: any;
    subCategoryName : any;
    subCategoryId : any;
    image : any;
    selectedFile: File;
    imgURL: any;
    retrievedImage: any;
    base64Data: any;
    retrieveResponse: any;
    message: string;
  
  
    constructor(private itemService : SellerServiceService) { }

  ngOnInit(): void {
  }

  public onFileChanged(event) {
    //Select File
    this.selectedFile = event.target.files[0];
  }


  onItemSubmit() {
    console.log(this.selectedFile);
    const uploadProductData = new FormData();
    uploadProductData.append('imageFile', this.selectedFile, this.selectedFile.name);
    uploadProductData.append('itemname', this.itemName);
    uploadProductData.append('seller','1');
    uploadProductData.append('category', this.categoryId);
    uploadProductData.append('subcategory', this.subCategoryId);
    uploadProductData.append('price', this.price);
    uploadProductData.append('stock', this.stock);
    uploadProductData.append('desc',this.description);
    uploadProductData.append('remark',this.remarks);

    this.itemService.addProduct(uploadProductData)
    .subscribe((response) => {
          if (response.status === 200) {
            alert("Product added Successfully");
          } else {
            alert("adding Product failed Try Again");
          }
        }
    );
    // this.httpClient.post('http://localhost:8989/mentorportal/sellerService/image/upload', uploadImageData, { observe: 'response' })
    //   .subscribe((response) => {
    //     if (response.status === 200) {
    //       this.message = 'Image uploaded successfully';
    //     } else {
    //       this.message = 'Image not uploaded successfully';
    //     }
    //   }
    //   );
  }
}
