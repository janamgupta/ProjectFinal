import { Component, OnInit } from '@angular/core';
import { SellerServiceService } from '../seller-service.service';
import { Seller } from '../seller';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  constructor(private sellerService : SellerServiceService) { }

  mySeller : Seller;
  
  ngOnInit(): void {
      this.sellerInfo();
  }

  sellerInfo(){
    this.mySeller = new Seller();
    this.sellerService.getSellerById().subscribe(seller => this.mySeller = seller);
  }
}
