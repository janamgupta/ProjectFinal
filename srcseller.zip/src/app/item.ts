export class ItemDetails{

    itemName : string;
	price : number;
    stock : number;
	description : string;
    remarks : number;
    
}