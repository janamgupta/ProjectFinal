export class ItemDetails{

    itemName : string;
	price : number;
    stock : number;
	description : string;
    remarks : number;
    category : Category;
    subCategory : SubCategory;
    image : any;
}

export class Category{

    categoryName : string;
    briefDetail : string;
    
}

export class SubCategory{

    subCategoryName : string;
	category : Category;
	briefDetail : String;
	gst : number;
}