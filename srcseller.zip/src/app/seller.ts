export class Seller {

    username : string;
	companyName : string;
	gstin : string;
	briefAboutCompany : string;
	website : string;
	email : string;
    contactNumber : number;
    
}