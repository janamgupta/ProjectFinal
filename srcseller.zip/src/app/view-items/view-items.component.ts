import { Component, OnInit } from '@angular/core';
import { ItemDetails } from '../item';
import { SellerServiceService } from '../seller-service.service';

@Component({
  selector: 'app-view-items',
  templateUrl: './view-items.component.html',
  styleUrls: ['./view-items.component.css']
})
export class ViewItemsComponent implements OnInit {

  constructor(private sellerService : SellerServiceService) { }
  items : ItemDetails[];
  ngOnInit(): void {
  }

  viewProduct(){
    this.items = new Array();
    this.sellerService.getProductOfSeller().subscribe(product=> this.items = product);
  }
}
